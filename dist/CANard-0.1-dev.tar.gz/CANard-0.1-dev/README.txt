======
CANard
======

CANard is a library for dealing with Controller Area Network (CAN) data from
Python.
